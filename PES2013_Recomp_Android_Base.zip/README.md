# PES 2013 Recomp Android — base inicial

Inclui interface Android nativa, tema escuro/verde-limão, seletor de arquivo ISO/XEX, preferência local de perfil gráfico e workflow GitHub Actions.

**Limitação:** esta base NÃO inclui um emulador Xbox 360 e não executa PES 2013. O botão JOGAR informa que o núcleo ainda não foi integrado. Selecionar a ISO só guarda uma referência ao arquivo.

Para gerar um APK debug, mantenha a estrutura de pastas no GitHub e execute o workflow `Build PES 2013 Android APK`. O artefato ficará disponível em Actions quando a compilação tiver sucesso.

A integração posterior do núcleo depende de compatibilidade Android/ARM64, GPU/Vulkan, licença e suporte específico ao PES 2013.
