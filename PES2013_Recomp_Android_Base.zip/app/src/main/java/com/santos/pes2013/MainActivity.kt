package com.santos.pes2013

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val lime = Color.rgb(183, 243, 107)
    private val dark = Color.rgb(20, 25, 21)
    private val panel = Color.rgb(34, 42, 35)
    private val white = Color.rgb(246, 248, 244)
    private val muted = Color.rgb(190, 201, 188)
    private val prefs by lazy { getSharedPreferences("pes_settings", MODE_PRIVATE) }
    private var selectedUri: Uri? = null
    private lateinit var isoLabel: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedUri = prefs.getString("iso_uri", null)?.let(Uri::parse)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(dark)
        }
        scroll.addView(root)
        root.addView(label("FOOTBALL • CLASSIC EDITION", 12, lime, true))
        root.addView(label("PES 2013", 42, white, true))
        root.addView(label("XBOX 360 EDITION  •  ANDROID", 12, muted, false))
        val play = Button(this).apply {
            text = "▶   JOGAR"; textSize = 18f; setTextColor(dark); setBackgroundColor(lime)
            setOnClickListener { status.text = "O núcleo de emulação ainda não foi integrado. Este APK-base não executa a ISO." }
        }
        root.addView(play, match())
        root.addView(section("ARQUIVOS DO JOGO"))
        val fileBox = box()
        isoLabel = label("Nenhuma ISO selecionada", 14, white, true)
        fileBox.addView(isoLabel, match())
        fileBox.addView(Button(this).apply {
            text = "Selecionar ISO / XEX"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-iso9660-image"))
                }
                startActivityForResult(i, 101)
            }
        }, match())
        root.addView(fileBox, match())
        root.addView(section("PERFIL GRÁFICO"))
        val settingBox = box()
        settingBox.addView(label("Predefinição", 14, muted, false), match())
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Desempenho", "Equilibrado", "Qualidade"))
        spinner.setSelection(prefs.getInt("quality", 1).coerceIn(0, 2))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { prefs.edit().putInt("quality", position).apply() }
        }
        settingBox.addView(spinner, match())
        settingBox.addView(label("As opções reais de resolução/renderização dependem do núcleo de emulação a integrar.", 12, muted, false), match())
        root.addView(settingBox, match())
        root.addView(section("ESTADO DO PROJETO"))
        status = label("Interface inicial pronta. Núcleo do Xbox 360 ainda não integrado.", 13, white, false)
        status.setPadding(dp(12), dp(12), dp(12), dp(12)); status.setBackgroundColor(panel)
        root.addView(status, match())
        root.addView(label("Selecionar uma ISO não executa o jogo. É necessário integrar e validar um núcleo de emulação compatível.", 11, muted, false))
        setContentView(scroll)
        updateIsoLabel()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedUri = uri
            prefs.edit().putString("iso_uri", uri.toString()).apply()
            updateIsoLabel()
            status.text = "Arquivo selecionado. O jogo ainda não pode iniciar sem um núcleo de emulação."
        }
    }

    private fun updateIsoLabel() { isoLabel.text = selectedUri?.lastPathSegment?.substringAfterLast('/') ?: "Nenhuma ISO selecionada" }
    private fun label(t: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = t; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        setPadding(0, dp(7), 0, dp(7))
    }
    private fun section(t: String) = label(t, 12, lime, true).apply { setPadding(0, dp(22), 0, dp(8)) }
    private fun box() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); setBackgroundColor(panel) }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
